# scrum-process
Repositório destinado a modelagem do processo do Scrum para a matéria Tecnologia de Processos de Software.
