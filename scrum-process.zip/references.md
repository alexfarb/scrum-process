A BPM view on Scrum (Principal): http://www.ariscommunity.com/users/sstein/2010-08-09-bpm-view-scrum
Agile Scrum Flow Chart: https://anasr.net/2012/02/17/agile-scrum-flow-chart/